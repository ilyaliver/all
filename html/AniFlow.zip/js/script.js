document.addEventListener('DOMContentLoaded', () => {
    const burgerMenu = document.getElementById('burger-menu');
    const mobileNav = document.getElementById('mobile-nav');
    const mobileLinks = document.querySelectorAll('.mobile-nav-link');
    const toast = document.getElementById('toast');
    const downloadBtns = document.querySelectorAll('a[href="#download"], .btn-primary');

    // Mobile Menu Toggle
    burgerMenu.addEventListener('click', () => {
        mobileNav.classList.toggle('active');
        
        // Burger animation
        const spans = burgerMenu.querySelectorAll('span');
        spans[0].style.transform = mobileNav.classList.contains('active') ? 'rotate(45deg) translate(5px, 6px)' : 'none';
        spans[1].style.opacity = mobileNav.classList.contains('active') ? '0' : '1';
        spans[2].style.transform = mobileNav.classList.contains('active') ? 'rotate(-45deg) translate(5px, -6px)' : 'none';
    });

    mobileLinks.forEach(link => {
        link.addEventListener('click', () => {
            mobileNav.classList.remove('active');
            const spans = burgerMenu.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        });
    });

    // Toast Notification logic
    const showToast = () => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    };

    downloadBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            if (btn.getAttribute('href') === '#download') {
                showToast();
            }
        });
    });

    // Scroll Animations
    const revealElements = document.querySelectorAll('section, .feature-card, .anime-card, .review-card');
    
    const revealOnScroll = () => {
        revealElements.forEach(el => {
            const windowHeight = window.innerHeight;
            const elementTop = el.getBoundingClientRect().top;
            const elementVisible = 150;

            if (elementTop < windowHeight - elementVisible) {
                el.classList.add('active');
            }
        });
    };

    // Add reveal class to elements initially
    revealElements.forEach(el => el.classList.add('reveal'));
    
    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll(); // Initial check
});
