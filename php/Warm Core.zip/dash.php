<?php

declare(strict_types=1);

require_once __DIR__ . '/core/bootstrap.php';

if (!$user = current_user()) {
    redirect('/login/');
}

$sessionActionToken = $_SESSION['session_action_token'] ??= bin2hex(random_bytes(32));
$profileErrors = [];
$securityErrors = [];
$totpEnabled = (int) ($user['topt_status'] ?? 0) === 1 && !empty($user['totp_secret']);

if (!$totpEnabled && empty($_SESSION['totp_setup_secret'])) {
    $_SESSION['totp_setup_secret'] = totp_generate_secret();
}

$totpSetupSecret = $totpEnabled ? null : (string) $_SESSION['totp_setup_secret'];
$totpSetupUri = $totpSetupSecret ? totp_uri($totpSetupSecret, (string) $user['email']) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $submittedToken = (string) ($_POST['csrf_token'] ?? '');
    if (!hash_equals($sessionActionToken, $submittedToken)) {
        if (in_array($action, ['update_profile', 'enable_totp', 'disable_totp'], true)) {
            set_flash($action === 'update_profile' ? 'error' : 'security_error', 'Запрос устарел. Обновите страницу.');
            redirect('/dash/');
        }

        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        echo json_encode(['ok' => false, 'message' => 'Запрос устарел. Обновите страницу.']);
        exit;
    }

    if ($action === 'update_profile') {
        if (!$totpEnabled) {
            set_flash('error', 'Сначала настройте Google Authenticator в блоке безопасности.');
            redirect('/dash/#security');
        }

        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));

        if ($name === '') {
            $profileErrors[] = 'Укажите имя.';
        } elseif (mb_strlen($name) > 120) {
            $profileErrors[] = 'Имя не должно быть длиннее 120 символов.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $profileErrors[] = 'Укажите корректный email.';
        } elseif (strlen($email) > 190) {
            $profileErrors[] = 'Email не должен быть длиннее 190 символов.';
        }

        if (!$profileErrors) {
            $statement = db()->prepare('SELECT id FROM users WHERE email = :email AND id <> :id LIMIT 1');
            $statement->execute(['email' => $email, 'id' => $user['id']]);
            if ($statement->fetch()) {
                $profileErrors[] = 'Этот email уже используется другим аккаунтом.';
            }
        }

        if (!$profileErrors) {
            $statement = db()->prepare('UPDATE users SET name = :name, email = :email WHERE id = :id');
            $statement->execute(['name' => $name, 'email' => $email, 'id' => $user['id']]);
            set_flash('success', 'Данные профиля обновлены.');
            redirect('/dash/');
        }

        $user['name'] = $name;
        $user['email'] = $email;
    } elseif ($action === 'enable_totp') {
        $code = trim((string) ($_POST['totp_code'] ?? ''));
        $secret = (string) ($_SESSION['totp_setup_secret'] ?? '');
        $counter = $secret !== '' ? totp_verify($secret, $code) : null;

        if ($counter === null) {
            $securityErrors[] = 'Введите действующий шестизначный код из Google Authenticator.';
        } else {
            $statement = db()->prepare(
                'UPDATE users SET totp_secret = :secret, totp_enabled_at = NOW(), totp_last_counter = :counter, topt_status = 1 WHERE id = :id'
            );
            $statement->execute(['secret' => $secret, 'counter' => $counter, 'id' => $user['id']]);
            unset($_SESSION['totp_setup_secret']);
            end_other_user_sessions((int) $user['id']);
            set_flash('security_success', 'Google Authenticator подключён. Следующий вход потребует одноразовый код.');
            redirect('/dash/#security');
        }
    } elseif ($action === 'disable_totp') {
        $password = (string) ($_POST['password'] ?? '');
        $code = trim((string) ($_POST['totp_code'] ?? ''));
        $statement = db()->prepare('SELECT password_hash, totp_secret FROM users WHERE id = :id LIMIT 1');
        $statement->execute(['id' => $user['id']]);
        $securityUser = $statement->fetch();

        if (!$securityUser || !password_verify($password, (string) $securityUser['password_hash'])) {
            $securityErrors[] = 'Неверный пароль.';
        } elseif (!consume_totp_code((int) $user['id'], (string) $securityUser['totp_secret'], $code)) {
            $securityErrors[] = 'Неверный или уже использованный код Google Authenticator.';
        } else {
            $statement = db()->prepare(
                'UPDATE users SET totp_secret = NULL, totp_enabled_at = NULL, totp_last_counter = NULL, topt_status = 0 WHERE id = :id'
            );
            $statement->execute(['id' => $user['id']]);
            $_SESSION['totp_setup_secret'] = totp_generate_secret();
            end_other_user_sessions((int) $user['id']);
            set_flash('security_success', 'Двухфакторная аутентификация отключена. Профиль снова заблокирован.');
            redirect('/dash/#security');
        }
    } else {
        header('Content-Type: application/json; charset=utf-8');

    if ($action === 'end_others') {
        $endedCount = end_other_user_sessions((int) $user['id']);
        echo json_encode(['ok' => true, 'ended_count' => $endedCount]);
        exit;
    }

    $sessionId = (int) ($_POST['session_id'] ?? 0);
    if ($sessionId > 0) {
        end_user_session((int) $user['id'], $sessionId);
        echo json_encode(['ok' => true]);
        exit;
    }

    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Неизвестное действие.']);
    exit;
    }
}

$sessions = get_user_sessions($user['id']);
$activeSessions = array_filter($sessions, fn($s) => (bool) $s['is_active']);
$historySessions = array_filter($sessions, fn($s) => !$s['is_active']);
$currentSessionToken = session_id();
$otherActiveSessionCount = count(array_filter(
    $activeSessions,
    fn($s) => !hash_equals($currentSessionToken, (string) $s['session_token'])
));

$pageTitle = 'Личный кабинет - Warm Core';
require __DIR__ . '/partials/header.php';
?>

<section class="section cabinet-section" aria-labelledby="cabinet-title">
    <div class="auth-card" style="padding: 24px 32px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
        <div>
            <h1 id="cabinet-title" style="font-size: 28px; margin: 0;"><?= e($user['name']) ?></h1>
            <p style="margin: 8px 0 0; color: var(--muted); font-size: 14px;"><?= e($user['email']) ?></p>
            <p style="margin: 6px 0 0; color: var(--muted); font-size: 14px;">ID аккаунта: <?= (int) $user['id'] ?></p>
            <p style="margin: 6px 0 0; color: var(--muted); font-size: 14px;">Аккаунт создан: <?= e(date('d.m.Y', strtotime($user['created_at']))) ?></p>
            <p style="margin: 6px 0 0; color: var(--muted); font-size: 14px;">Вы: <?= ($user['role'] ?? '') === 'administrator' ? 'Администратор' : 'Пользователь' ?></p>
        </div>
        <a class="button button-secondary" href="/logout.php">Выйти</a>
    </div>

    <div style="margin-top: 32px;">
        <h2 style="font-size: 28px; margin: 0 0 20px;">Профиль</h2>
        <form class="auth-card" method="post" action="/dash/" style="padding: 24px 32px;">
            <input type="hidden" name="action" value="update_profile">
            <input type="hidden" name="csrf_token" value="<?= e($sessionActionToken) ?>">

            <?php if ($profileErrors): ?>
                <div class="alert alert-error"><?= e(implode(' ', $profileErrors)) ?></div>
            <?php elseif ($profileSuccess = flash('success')): ?>
                <div class="alert alert-success"><?= e($profileSuccess) ?></div>
            <?php elseif ($profileError = flash('error')): ?>
                <div class="alert alert-error"><?= e($profileError) ?></div>
            <?php endif; ?>

            <?php if (!$totpEnabled): ?>
                <div class="alert alert-error">Профиль недоступен, пока не настроен Google Authenticator. Подключите его в блоке «Безопасность» ниже.</div>
            <?php endif; ?>

            <div class="form-group">
                <label for="profile-name">Имя</label>
                <input id="profile-name" name="name" type="text" maxlength="120" value="<?= e($user['name']) ?>" autocomplete="name" required <?= $totpEnabled ? '' : 'disabled' ?>>
            </div>

            <div class="form-group">
                <label for="profile-email">Email</label>
                <input id="profile-email" name="email" type="email" maxlength="190" value="<?= e($user['email']) ?>" autocomplete="email" required <?= $totpEnabled ? '' : 'disabled' ?>>
            </div>

            <div class="form-actions">
                <button class="button-primary" type="submit" <?= $totpEnabled ? '' : 'disabled' ?>>Сохранить изменения</button>
            </div>
        </form>
    </div>

    <div id="security" style="margin-top: 32px; scroll-margin-top: 24px;">
        <h2 style="font-size: 28px; margin: 0 0 20px;">Безопасность</h2>
        <div class="auth-card" style="padding: 24px 32px;">
            <?php if ($securityErrors): ?>
                <div class="alert alert-error"><?= e(implode(' ', $securityErrors)) ?></div>
            <?php elseif ($securitySuccess = flash('security_success')): ?>
                <div class="alert alert-success"><?= e($securitySuccess) ?></div>
            <?php elseif ($securityError = flash('security_error')): ?>
                <div class="alert alert-error"><?= e($securityError) ?></div>
            <?php endif; ?>

            <?php if ($totpEnabled): ?>
                <h3 style="margin-top: 0; color: var(--success);">Google Authenticator подключён</h3>
                <p style="color: var(--muted);">После ввода email и пароля система запрашивает шестизначный код. Для отключения подтвердите действие паролем и текущим кодом.</p>
                <form method="post" action="/dash/#security" style="margin-top: 24px;">
                    <input type="hidden" name="action" value="disable_totp">
                    <input type="hidden" name="csrf_token" value="<?= e($sessionActionToken) ?>">
                    <div class="form-group">
                        <label for="security-password">Текущий пароль</label>
                        <input id="security-password" name="password" type="password" autocomplete="current-password" required>
                    </div>
                    <div class="form-group">
                        <label for="disable-totp-code">Код Google Authenticator</label>
                        <input id="disable-totp-code" name="totp_code" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>
                    </div>
                    <button class="button button-secondary" type="submit">Отключить двухфакторную аутентификацию</button>
                </form>
            <?php else: ?>
                <h3 style="margin-top: 0;">Подключение Google Authenticator</h3>
                <p style="color: var(--muted);">Отсканируйте QR-код приложением Google Authenticator или добавьте ключ вручную, затем введите полученный код.</p>
                <div style="display: flex; gap: 28px; align-items: center; flex-wrap: wrap; margin: 24px 0;">
                    <div id="totp-qr" style="width: 200px; min-height: 200px; padding: 12px; background: #fff; border-radius: 10px; display: grid; place-items: center;" aria-label="QR-код Google Authenticator"></div>
                    <div style="min-width: 0;">
                        <p style="margin-top: 0; color: var(--muted);">Ключ настройки:</p>
                        <code style="display: block; overflow-wrap: anywhere; font-size: 16px;"><?= e((string) $totpSetupSecret) ?></code>
                        <p style="margin-bottom: 0; color: var(--muted); font-size: 14px;">Тип: по времени (TOTP), 6 цифр, период 30 секунд.</p>
                    </div>
                </div>
                <form method="post" action="/dash/#security">
                    <input type="hidden" name="action" value="enable_totp">
                    <input type="hidden" name="csrf_token" value="<?= e($sessionActionToken) ?>">
                    <div class="form-group">
                        <label for="enable-totp-code">Код из приложения</label>
                        <input id="enable-totp-code" name="totp_code" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>
                    </div>
                    <button class="button-primary" type="submit">Подключить Google Authenticator</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div style="margin-top: 32px;">
        <h2 style="font-size: 28px; margin: 0 0 20px;">Настройки</h2>
        <div class="auth-card" style="padding: 24px 32px;">
            <p style="margin: 0; color: var(--muted);">Здесь будут доступны настройки пароля, уведомлений и интерфейса.</p>
        </div>
    </div>

    <div style="margin-top: 32px;">
        <h2 style="font-size: 28px; margin: 0 0 20px;">Сессии</h2>

        <?php if ($activeSessions): ?>
            <div class="sessions-panel" style="border-radius: 12px; background: var(--surface-card); padding: 24px; margin-bottom: 24px;">
                <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 16px;">
                    <h3 style="font-size: 18px; margin: 0; color: var(--success);">Активные сессии</h3>
                    <?php if ($otherActiveSessionCount > 0): ?>
                        <button class="button button-secondary" id="end-other-sessions" style="padding: 8px 14px; min-height: 36px;" onclick="endOtherSessions(this)">
                            Завершить остальные (<?= $otherActiveSessionCount ?>)
                        </button>
                    <?php endif; ?>
                </div>
                <div class="sessions-table-wrap">
                    <table class="sessions-table">
                        <thead>
                            <tr>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Статус</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">IP адрес</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Браузер</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Язык</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Дата авторизации</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Последняя активность</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Действие</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($activeSessions as $sess): ?>
                                <?php $isCurrentSession = hash_equals($currentSessionToken, (string) $sess['session_token']); ?>
                                <tr style="border-bottom: 1px solid var(--hairline-soft);">
                                    <td style="padding: 12px;">
                                        <span class="badge badge-active"><?= $isCurrentSession ? 'Текущая' : 'Активна' ?></span>
                                    </td>
                                    <td style="padding: 12px; font-family: 'JetBrains Mono', monospace; font-size: 13px;"><?= e($sess['ip_address']) ?></td>
                                    <td style="padding: 12px; font-size: 13px; max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= e($sess['user_agent']) ?>"><?= e(truncate_user_agent($sess['user_agent'])) ?></td>
                                    <td style="padding: 12px; font-size: 13px;"><?= e($sess['browser_language'] ?: '-') ?></td>
                                    <td style="padding: 12px; font-size: 13px;"><?= e(date('d.mY H:i', strtotime($sess['created_at']))) ?></td>
                                    <td style="padding: 12px; font-size: 13px;"><?= e(date('d.mY H:i', strtotime($sess['last_activity']))) ?></td>
                                    <td style="padding: 12px;">
                                        <?php if ($isCurrentSession): ?>
                                            <span style="color: var(--muted); font-size: 13px;">Это устройство</span>
                                        <?php else: ?>
                                            <button class="button button-secondary btn-end-session" data-session-id="<?= (int) $sess['id'] ?>" style="padding: 6px 14px; font-size: 13px; min-height: 32px;" onclick="endSession(this)">Завершить</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($historySessions): ?>
            <div class="sessions-panel" style="border-radius: 12px; background: var(--surface-card); padding: 24px;">
                <h3 style="font-size: 18px; margin: 0 0 16px; color: var(--muted);">История сессий</h3>
                <div class="sessions-table-wrap">
                    <table class="sessions-table">
                        <thead>
                            <tr>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Статус</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">IP адрес</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Браузер</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Язык</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Дата авторизации</th>
                                <th style="text-align: left; padding: 8px 12px; font-size: 13px; color: var(--muted); font-weight: 500; border-bottom: 1px solid var(--hairline);">Последняя активность</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($historySessions as $sess): ?>
                                <tr style="border-bottom: 1px solid var(--hairline-soft);">
                                    <td style="padding: 12px;">
                                        <span class="badge badge-inactive">Завершена</span>
                                    </td>
                                    <td style="padding: 12px; font-family: 'JetBrains Mono', monospace; font-size: 13px;"><?= e($sess['ip_address']) ?></td>
                                    <td style="padding: 12px; font-size: 13px; max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= e($sess['user_agent']) ?>"><?= e(truncate_user_agent($sess['user_agent'])) ?></td>
                                    <td style="padding: 12px; font-size: 13px;"><?= e($sess['browser_language'] ?: '-') ?></td>
                                    <td style="padding: 12px; font-size: 13px;"><?= e(date('d.mY H:i', strtotime($sess['created_at']))) ?></td>
                                    <td style="padding: 12px; font-size: 13px;"><?= e(date('d.mY H:i', strtotime($sess['last_activity']))) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!$sessions): ?>
            <div style="border-radius: 12px; background: var(--surface-card); padding: 32px; text-align: center; color: var(--muted);">
                Сессий пока нет.
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
const sessionActionToken = <?= json_encode($sessionActionToken, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const totpSetupUri = <?= json_encode($totpSetupUri, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

if (totpSetupUri) {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
    script.onload = function() {
        new QRCode(document.getElementById('totp-qr'), {
            text: totpSetupUri,
            width: 176,
            height: 176,
            correctLevel: QRCode.CorrectLevel.M
        });
    };
    document.head.appendChild(script);
}

function sendSessionAction(params) {
    params.append('csrf_token', sessionActionToken);

    return fetch('/dash/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
    }).then(function(response) {
        return response.json().then(function(data) {
            if (!response.ok) {
                throw new Error(data.message || 'Ошибка при завершении сессии');
            }
            return data;
        });
    });
}

function endSession(btn) {
    const sessionId = btn.getAttribute('data-session-id');
    const data = new URLSearchParams();
    data.append('session_id', sessionId);

    btn.disabled = true;
    sendSessionAction(data)
    .then(function(data) {
        if (data.ok) {
            location.reload();
        } else {
            alert(data.message || 'Ошибка при завершении сессии');
        }
    })
    .catch(function(error) {
        btn.disabled = false;
        alert(error.message || 'Ошибка соединения с сервером');
    });
}

function endOtherSessions(btn) {
    if (!confirm('Завершить все активные сессии, кроме текущей?')) {
        return;
    }

    const data = new URLSearchParams();
    data.append('action', 'end_others');
    btn.disabled = true;

    sendSessionAction(data)
    .then(function(data) {
        if (data.ok) {
            location.reload();
        } else {
            btn.disabled = false;
            alert(data.message || 'Ошибка при завершении сессий');
        }
    })
    .catch(function(error) {
        btn.disabled = false;
        alert(error.message || 'Ошибка соединения с сервером');
    });
}
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
