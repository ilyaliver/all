<?php

declare(strict_types=1);

require_once __DIR__ . '/core/bootstrap.php';

if (is_authenticated()) {
    redirect('/dash/');
}

$errors = [];

if (empty($_SESSION['register_captcha'])) {
    $_SESSION['register_captcha'] = (string) random_int(10000, 99999);
}

if (empty($_SESSION['register_honeypot']) || !is_array($_SESSION['register_honeypot'])) {
    $_SESSION['register_honeypot'] = [
        'field' => 'profile_' . bin2hex(random_bytes(6)),
        'check' => 'accept_' . bin2hex(random_bytes(6)),
    ];
}

$honeypot = $_SESSION['register_honeypot'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $passwordConfirmation = (string) ($_POST['password_confirmation'] ?? '');
    $captcha = trim((string) ($_POST['captcha'] ?? ''));

    if (trim((string) ($_POST[$honeypot['field']] ?? '')) !== '' || isset($_POST[$honeypot['check']])) {
        $errors[] = 'Форма отправлена некорректно.';
        $_SESSION['register_captcha'] = (string) random_int(10000, 99999);
        $_SESSION['register_honeypot'] = [
            'field' => 'profile_' . bin2hex(random_bytes(6)),
            'check' => 'accept_' . bin2hex(random_bytes(6)),
        ];
        $honeypot = $_SESSION['register_honeypot'];
    }

    if ($name === '') {
        $errors[] = 'Укажите имя.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Укажите корректный email.';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Пароль должен быть не короче 6 символов.';
    }

    if ($password !== $passwordConfirmation) {
        $errors[] = 'Пароли не совпадают.';
    }

    if ($captcha === '' || !hash_equals((string) $_SESSION['register_captcha'], $captcha)) {
        $errors[] = 'Введите правильный код с картинки.';
        $_SESSION['register_captcha'] = (string) random_int(10000, 99999);
    }

    if (!$errors) {
        $statement = db()->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $statement->execute(['email' => $email]);

        if ($statement->fetch()) {
            $errors[] = 'Пользователь с таким email уже зарегистрирован.';
        }
    }

    if (!$errors) {
        $statement = db()->prepare('SELECT COUNT(*) as count FROM users');
        $statement->execute();
        $userCount = (int) $statement->fetch()['count'];

        $role = $userCount === 0 ? 'administrator' : 'user';

        $statement = db()->prepare(
            'INSERT INTO users (name, email, password_hash, role) VALUES (:name, :email, :password_hash, :role)'
        );
        $statement->execute([
            'name' => $name,
            'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role,
        ]);

        clear_old();
        unset($_SESSION['register_captcha']);
        set_flash('success', 'Аккаунт создан. Теперь войдите в систему.');
        redirect('/login/');
    }

    store_old(['name' => $name, 'email' => $email]);
}

$pageTitle = 'Регистрация - Warm Core';
require __DIR__ . '/partials/header.php';
?>

<section class="auth-page">
    <div class="auth-copy">
        <span class="eyebrow">Регистрация</span>
        <h1>Создайте аккаунт для доступа к сайту.</h1>
        <p class="lead">Данные сохраняются в MySQL, пароль хранится только в виде безопасного хеша.</p>
    </div>

    <form class="auth-card" method="post" action="/signup/" novalidate>
        <?php if ($errors): ?>
            <div class="alert alert-error"><?= e(implode(' ', $errors)) ?></div>
        <?php endif; ?>

        <div class="form-group">
            <label for="name">Имя</label>
            <input id="name" name="name" type="text" value="<?= e(old('name')) ?>" autocomplete="name" required>
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" value="<?= e(old('email')) ?>" autocomplete="email" required>
        </div>

        <div class="form-group">
            <label for="password">Пароль</label>
            <input id="password" name="password" type="password" autocomplete="new-password" required>
        </div>

        <div class="form-group">
            <label for="password_confirmation">Повторите пароль</label>
            <input id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" required>
        </div>

        <div class="auth-honeypot" aria-hidden="true">
            <label for="<?= e($honeypot['field']) ?>">Название компании</label>
            <input id="<?= e($honeypot['field']) ?>" name="<?= e($honeypot['field']) ?>" type="text" value="" tabindex="-1" autocomplete="off">
            <label class="checkbox-trap" for="<?= e($honeypot['check']) ?>">
                <input id="<?= e($honeypot['check']) ?>" name="<?= e($honeypot['check']) ?>" type="checkbox" value="1" tabindex="-1" autocomplete="off">
                Подтвердить автоматическую регистрацию
            </label>
        </div>

        <div class="form-group">
            <label for="captcha">Введите код</label>
            <div class="captcha-code" aria-label="Код подтверждения"><?= e((string) $_SESSION['register_captcha']) ?></div>
            <input id="captcha" name="captcha" type="text" inputmode="numeric" pattern="[0-9]{5}" maxlength="5" autocomplete="off" required>
        </div>

        <div class="form-actions">
            <button class="button-primary" type="submit">Зарегистрироваться</button>
            <div class="form-note">Уже есть аккаунт? <a href="/login/">Войти</a></div>
        </div>
    </form>
</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
