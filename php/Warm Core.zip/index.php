<?php

declare(strict_types=1);

require_once __DIR__ . '/core/bootstrap.php';

$pageTitle = 'Warm Core - Главная';
require __DIR__ . '/partials/header.php';
?>

<section class="hero-band">
    <div>
        <span class="eyebrow">Базовое ядро сайта</span>
        <h1>Теплая, строгая основа для проекта на PHP и MySQL.</h1>
        <p class="lead">Главная страница, регистрация, вход и сессия пользователя уже собраны в минимальное ядро для XAMPP.</p>
        <div class="hero-actions">
            <?php if ($user): ?>
                <a class="button button-primary" href="/dash/">Открыть кабинет</a>
                <a class="button button-secondary" href="/logout.php">Завершить сеанс</a>
            <?php else: ?>
                <a class="button button-primary" href="/signup/">Создать аккаунт</a>
                <a class="button button-secondary" href="/login/">Войти</a>
            <?php endif; ?>
        </div>
    </div>

    <aside class="product-card" aria-label="Состояние ядра">
        <div class="product-card-header">
            <span>core/status</span>
            <span><?= $user ? 'authenticated' : 'guest' ?></span>
        </div>
        <div class="code-window">
            <div><span class="code-muted">01</span> <span class="code-accent">database</span>: MySQL PDO</div>
            <div><span class="code-muted">02</span> <span class="code-accent">auth</span>: password_hash</div>
            <div><span class="code-muted">03</span> <span class="code-accent">session</span>: secure login</div>
            <div><span class="code-muted">04</span> <span class="code-accent">design</span>: cream/coral/dark</div>
        </div>
    </aside>
</section>

<section class="section">
    <h2>Что входит в основу</h2>
    <div class="feature-grid">
        <article class="feature-card">
            <span class="badge">Core</span>
            <h3>Ядро</h3>
            <p>Общий bootstrap, helper-функции, PDO-подключение и функции текущего пользователя.</p>
        </article>
        <article class="feature-card">
            <span class="badge">Auth</span>
            <h3>Авторизация</h3>
            <p>Регистрация с хешированием пароля, вход по email и безопасное завершение сессии.</p>
        </article>
        <article class="feature-card">
            <span class="badge">UI</span>
            <h3>Интерфейс</h3>
            <p>Адаптивная верстка, теплый canvas, coral CTA, темная продуктовая поверхность.</p>
        </article>
    </div>
</section>

<section class="section">
    <div class="callout">
        <h2>Готово для дальнейшей разработки.</h2>
        <p>Можно добавлять личный кабинет, роли, страницы контента и административную часть, сохраняя текущее ядро.</p>
    </div>
</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
