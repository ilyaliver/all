ALTER TABLE `users`
  ADD COLUMN `topt_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = disabled, 1 = enabled' AFTER `totp_last_counter`;

UPDATE `users`
SET `topt_status` = 1
WHERE `totp_secret` IS NOT NULL AND `totp_enabled_at` IS NOT NULL;
