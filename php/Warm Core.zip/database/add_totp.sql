ALTER TABLE `users`
  ADD COLUMN `totp_secret` varchar(64) DEFAULT NULL AFTER `role`,
  ADD COLUMN `totp_enabled_at` timestamp NULL DEFAULT NULL AFTER `totp_secret`,
  ADD COLUMN `totp_last_counter` bigint(20) UNSIGNED DEFAULT NULL AFTER `totp_enabled_at`,
  ADD COLUMN `topt_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = disabled, 1 = enabled' AFTER `totp_last_counter`;
