# AGENT.md

## Goal

Modernize the visual design of this project while preserving the existing functionality.

The project may contain old but working code. The main task is to improve the UI, UX, layout, responsiveness, and visual consistency using DESIGN.md as the design source of truth.

## Design Source

Use DESIGN.md as the primary visual reference.

Follow its:
- colors
- typography
- spacing
- components
- border radius
- surface system
- responsive behavior
- visual tone

Do not invent a new design direction unless explicitly requested.

## Preserve Functionality

Do not change existing functionality unless explicitly requested.

Preserve:
- JavaScript behavior
- element IDs used by scripts
- form actions and methods
- API endpoints
- URL structure
- SEO meta tags
- analytics scripts
- external integrations
- existing user flows
- download/upload behavior
- validation behavior
- server-side template variables

If a visual change requires changing functional markup, first identify the risk and choose the smallest safe change.

## Visual-Only Changes

Prefer visual-layer changes when possible:
- CSS updates
- layout improvements
- spacing fixes
- typography improvements
- responsive improvements
- accessibility improvements
- non-functional decorative HTML

Avoid rewriting business logic.

## Code Style

Keep changes minimal and focused.

Do not add unnecessary frameworks, dependencies, build steps, or abstractions.

Prefer readable HTML/CSS/JS over clever solutions.

## No Emoji Rule

Do not use emoji inside code, comments, class names, IDs, strings, logs, UI labels, or documentation unless the user explicitly requests it.

Use plain text, icons via CSS/SVG, or accessible labels instead.

## Legacy Code Rules

Old code may be messy but functional.

Do not delete legacy code unless:
- it is clearly unused
- it blocks the redesign
- its removal is safe
- the reason is documented

When unsure, preserve it.

## Accessibility

Improve accessibility where possible without changing functionality:
- semantic HTML
- labels for inputs
- focus-visible states
- sufficient contrast
- keyboard navigation
- reduced motion support

## Responsive Behavior

The updated design must work on:
- desktop
- tablet
- mobile

Do not design only for desktop.

## Verification

After changes, verify:
- core user flow still works
- important IDs are still present
- buttons/forms still behave correctly
- layout does not break on mobile
- no accidental functional changes were introduced

## Working Principle

Functionality is the asset.  
Design is the layer being modernized.

When in doubt, preserve behavior and improve only presentation.

## Strict Non-Goals

Do not:
- redesign the product logic
- replace working JavaScript without need
- migrate the project to another framework
- add animations that affect usability
- add emoji or decorative Unicode symbols
- remove SEO or analytics code
- change external service URLs

## Before Editing

Before making changes:
1. Identify the core functionality.
2. Identify IDs/classes/scripts that are functionally important.
3. Read DESIGN.md.
4. Prefer the smallest safe visual change.