<?php

declare(strict_types=1);

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $statement = db()->prepare(
        'SELECT users.id, users.name, users.email, users.role, users.created_at,
                users.totp_secret, users.totp_enabled_at, users.topt_status
         FROM users
         INNER JOIN user_sessions ON user_sessions.user_id = users.id
         WHERE users.id = :id AND user_sessions.session_token = :token AND user_sessions.is_active = 1
         LIMIT 1'
    );
    $statement->execute([
        'id' => $_SESSION['user_id'],
        'token' => session_id(),
    ]);
    $user = $statement->fetch();

    return $user ?: null;
}

function is_authenticated(): bool
{
    return current_user() !== null;
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];

    record_session((int) $user['id']);
}

function consume_totp_code(int $userId, string $secret, string $code): bool
{
    $counter = totp_verify($secret, $code);
    if ($counter === null) {
        return false;
    }

    $statement = db()->prepare(
        'UPDATE users
         SET totp_last_counter = :counter
         WHERE id = :id AND (totp_last_counter IS NULL OR totp_last_counter < :counter)'
    );
    $statement->execute(['counter' => $counter, 'id' => $userId]);

    return $statement->rowCount() === 1;
}

function logout_user(): void
{
    if (isset($_SESSION['user_id'])) {
        invalidate_current_session((int) $_SESSION['user_id']);
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
}

function record_session(int $userId): void
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? null;

    $statement = db()->prepare(
        'INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, browser_language, is_active) VALUES (:user_id, :token, :ip, :ua, :lang, 1)'
    );

    $statement->execute([
        'user_id' => $userId,
        'token' => session_id(),
        'ip' => $ip,
        'ua' => $userAgent,
        'lang' => $lang,
    ]);
}

function get_user_sessions(int $userId): array
{
    $statement = db()->prepare(
        'SELECT id, session_token, ip_address, user_agent, browser_language, is_active, last_activity, created_at FROM user_sessions WHERE user_id = :user_id ORDER BY is_active DESC, last_activity DESC'
    );
    $statement->execute(['user_id' => $userId]);

    return $statement->fetchAll();
}

function invalidate_current_session(int $userId): void
{
    $statement = db()->prepare(
        'UPDATE user_sessions SET is_active = 0 WHERE user_id = :user_id AND session_token = :token'
    );
    $statement->execute([
        'user_id' => $userId,
        'token' => session_id(),
    ]);
}

function end_user_session(int $userId, int $sessionId): void
{
    $statement = db()->prepare(
        'UPDATE user_sessions
         SET is_active = 0
         WHERE user_id = :user_id AND id = :session_id AND session_token <> :current_token'
    );
    $statement->execute([
        'user_id' => $userId,
        'session_id' => $sessionId,
        'current_token' => session_id(),
    ]);
}

function end_other_user_sessions(int $userId): int
{
    $statement = db()->prepare(
        'UPDATE user_sessions
         SET is_active = 0
         WHERE user_id = :user_id AND is_active = 1 AND session_token <> :current_token'
    );
    $statement->execute([
        'user_id' => $userId,
        'current_token' => session_id(),
    ]);

    return $statement->rowCount();
}
