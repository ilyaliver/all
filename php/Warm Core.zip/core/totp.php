<?php

declare(strict_types=1);

function totp_generate_secret(int $bytes = 20): string
{
    return totp_base32_encode(random_bytes($bytes));
}

function totp_base32_encode(string $data): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $buffer = 0;
    $bits = 0;
    $result = '';

    foreach (unpack('C*', $data) as $byte) {
        $buffer = ($buffer << 8) | $byte;
        $bits += 8;

        while ($bits >= 5) {
            $bits -= 5;
            $result .= $alphabet[($buffer >> $bits) & 31];
        }

        $buffer &= $bits === 0 ? 0 : (1 << $bits) - 1;
    }

    if ($bits > 0) {
        $result .= $alphabet[($buffer << (5 - $bits)) & 31];
    }

    return $result;
}

function totp_base32_decode(string $encoded): string
{
    $alphabet = array_flip(str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'));
    $encoded = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $encoded) ?? '');
    $buffer = 0;
    $bits = 0;
    $result = '';

    foreach (str_split($encoded) as $character) {
        if (!isset($alphabet[$character])) {
            return '';
        }

        $buffer = ($buffer << 5) | $alphabet[$character];
        $bits += 5;

        if ($bits >= 8) {
            $bits -= 8;
            $result .= chr(($buffer >> $bits) & 255);
            $buffer &= $bits === 0 ? 0 : (1 << $bits) - 1;
        }
    }

    return $result;
}

function totp_code(string $secret, int $counter): string
{
    $key = totp_base32_decode($secret);
    $message = pack('N2', intdiv($counter, 4294967296), $counter % 4294967296);
    $hash = hash_hmac('sha1', $message, $key, true);
    $offset = ord($hash[19]) & 15;
    $binary = ((ord($hash[$offset]) & 127) << 24)
        | (ord($hash[$offset + 1]) << 16)
        | (ord($hash[$offset + 2]) << 8)
        | ord($hash[$offset + 3]);

    return str_pad((string) ($binary % 1000000), 6, '0', STR_PAD_LEFT);
}

function totp_verify(string $secret, string $code, int $window = 1): ?int
{
    $code = preg_replace('/\D/', '', $code) ?? '';
    if (strlen($code) !== 6) {
        return null;
    }

    $counter = intdiv(time(), 30);
    for ($offset = -$window; $offset <= $window; $offset++) {
        $candidateCounter = $counter + $offset;
        if ($candidateCounter >= 0 && hash_equals(totp_code($secret, $candidateCounter), $code)) {
            return $candidateCounter;
        }
    }

    return null;
}

function totp_uri(string $secret, string $email, string $issuer = 'Warm Core'): string
{
    $label = rawurlencode($issuer) . ':' . rawurlencode($email);

    return 'otpauth://totp/' . $label . '?secret=' . rawurlencode($secret)
        . '&issuer=' . rawurlencode($issuer) . '&algorithm=SHA1&digits=6&period=30';
}
