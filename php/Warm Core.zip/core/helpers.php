<?php

declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function old(string $key, string $default = ''): string
{
    return (string) ($_SESSION['old'][$key] ?? $default);
}

function flash(string $key): ?string
{
    if (!isset($_SESSION['flash'][$key])) {
        return null;
    }

    $message = (string) $_SESSION['flash'][$key];
    unset($_SESSION['flash'][$key]);

    return $message;
}

function set_flash(string $key, string $message): void
{
    $_SESSION['flash'][$key] = $message;
}

function store_old(array $values): void
{
    $_SESSION['old'] = $values;
}

function clear_old(): void
{
    unset($_SESSION['old']);
}

function is_admin(): bool
{
    $user = current_user();
    return $user !== null && ($user['role'] ?? '') === 'administrator';
}

function is_user(): bool
{
    $user = current_user();
    return $user !== null && ($user['role'] ?? '') === 'user';
}

function truncate_user_agent(string $ua): string
{
    $parts = [];

    if (preg_match('/Firefox\/([\d.]+)/', $ua, $m)) {
        $parts[] = 'Firefox ' . $m[1];
    } elseif (preg_match('/Chrome\/([\d.]+)/', $ua, $m)) {
        $chromeVersion = $m[1];
        $parts[] = 'Chrome ' . $chromeVersion;
        if (preg_match('/Edg\/([\d.]+)/', $ua, $em)) {
            $parts[count($parts) - 1] = 'Edge ' . $em[1];
        }
    } elseif (preg_match('/Safari\/([\d.]+)/', $ua, $m)) {
        $parts[] = 'Safari';
    } elseif (preg_match('/Opera\s+|OPR\//', $ua)) {
        $parts[] = 'Opera';
    } else {
        $parts[] = substr($ua, 0, 60);
    }

    if (preg_match('/Windows.*?Windows NT 10\.0/', $ua)) {
        $parts[] = 'Windows';
    } elseif (preg_match('/Macintosh|Mac OS X/', $ua)) {
        $parts[] = 'macOS';
    } elseif (preg_match('/Linux/', $ua)) {
        $parts[] = 'Linux';
    } elseif (preg_match('/Android/', $ua)) {
        $parts[] = 'Android';
    } elseif (preg_match('/iPhone|iPod/', $ua)) {
        $parts[] = 'iOS';
    }

    $result = implode(' / ', $parts);
    if (strlen($result) > 60) {
        $result = substr($result, 0, 57) . '...';
    }

    return $result;
}
