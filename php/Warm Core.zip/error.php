<?php

declare(strict_types=1);

require_once __DIR__ . '/core/helpers.php';

$requestedCode = (int) ($_GET['code'] ?? 404);
$errors = [
    400 => [
        'title' => 'Некорректный запрос',
        'label' => 'Bad Request',
        'summary' => 'Сервер не смог обработать запрос из-за неверного формата данных.',
        'detail' => 'Проверьте адрес, параметры ссылки или вернитесь на главную страницу.',
    ],
    401 => [
        'title' => 'Требуется авторизация',
        'label' => 'Unauthorized',
        'summary' => 'Для доступа к этому разделу нужно войти в аккаунт.',
        'detail' => 'После входа система вернет вас к защищенным разделам сайта.',
    ],
    403 => [
        'title' => 'Доступ закрыт',
        'label' => 'Forbidden',
        'summary' => 'У текущего пользователя нет прав для просмотра этой страницы.',
        'detail' => 'Если доступ должен быть открыт, обратитесь к администратору проекта.',
    ],
    404 => [
        'title' => 'Страница не найдена',
        'label' => 'Not Found',
        'summary' => 'Адрес больше не существует или был введен с ошибкой.',
        'detail' => 'Пока маршрут восстанавливается, можно собрать плитку 2048 прямо здесь.',
    ],
    500 => [
        'title' => 'Внутренняя ошибка',
        'label' => 'Internal Server Error',
        'summary' => 'На сервере произошла непредвиденная ошибка.',
        'detail' => 'Команда уже может проверить журнал ошибок и состояние приложения.',
    ],
    502 => [
        'title' => 'Плохой шлюз',
        'label' => 'Bad Gateway',
        'summary' => 'Промежуточный сервер получил некорректный ответ.',
        'detail' => 'Обычно это временная проблема между веб-сервером и upstream-сервисом.',
    ],
    503 => [
        'title' => 'Сервис недоступен',
        'label' => 'Service Unavailable',
        'summary' => 'Сайт временно не может обработать запрос.',
        'detail' => 'Попробуйте обновить страницу позже или вернитесь на главную.',
    ],
];

$statusCode = array_key_exists($requestedCode, $errors) ? $requestedCode : 404;
$error = $errors[$statusCode];

http_response_code($statusCode);

$skipUserLookup = true;
$pageTitle = $statusCode . ' - ' . $error['title'] . ' - Warm Core';
require __DIR__ . '/partials/header.php';
?>

<section class="error-page" aria-labelledby="error-title">
    <div class="error-copy">
        <span class="eyebrow">HTTP <?= $statusCode ?> / <?= e($error['label']) ?></span>
        <h1 id="error-title"><?= e($error['title']) ?>.</h1>
        <p class="lead"><?= e($error['summary']) ?></p>
        <p><?= e($error['detail']) ?></p>
        <div class="hero-actions">
            <a class="button button-primary" href="/">На главную</a>
            <?php if ($user): ?>
                <a class="button button-secondary" href="/dash/">В кабинет</a>
            <?php else: ?>
                <a class="button button-secondary" href="/login/">Войти</a>
            <?php endif; ?>
        </div>
    </div>

    <aside class="error-game-card" aria-labelledby="game-title">
        <div class="error-game-heading">
            <div>
                <span class="cabinet-label">Recovery game</span>
                <h2 id="game-title">2048</h2>
            </div>
            <div class="error-game-scores" aria-label="Счет игры">
                <div class="error-game-score">
                    <span>Счет</span>
                    <strong id="score">0</strong>
                    <b id="score-addition" class="score-addition"></b>
                </div>
                <div class="error-game-score">
                    <span>Рекорд</span>
                    <strong id="best">0</strong>
                </div>
            </div>
        </div>

        <div class="error-game-intro">
            <p>Соединяйте одинаковые числа, чтобы получить плитку <strong>2048</strong>.</p>
            <button class="button-secondary" id="restart" type="button">Новая игра</button>
        </div>

        <div class="game-container" aria-label="Игровое поле 2048">
            <div class="game-message" id="game-message" role="status" aria-live="polite">
                <p id="message-text"></p>
                <div class="game-message-actions">
                    <button class="button-secondary" id="keep-playing" type="button">Продолжить</button>
                    <button class="button-primary" id="retry" type="button">Заново</button>
                </div>
            </div>
            <div class="grid-container" id="grid-container" aria-hidden="true"></div>
            <div class="tile-container" id="tile-container"></div>
        </div>

        <p class="error-game-help">Управление: стрелки, WASD или свайпы на мобильном.</p>
    </aside>
</section>

<script>
(function(){
    "use strict";

    var SIZE = 4;
    var STORAGE_KEY = "error_page_2048_best";

    function Grid(size){
        this.size = size;
        this.cells = [];
        for (var x = 0; x < size; x++){
            var row = [];
            for (var y = 0; y < size; y++) row.push(null);
            this.cells.push(row);
        }
    }

    Grid.prototype.availableCells = function(){
        var cells = [];
        for (var x = 0; x < this.size; x++){
            for (var y = 0; y < this.size; y++){
                if (!this.cells[x][y]) cells.push({x:x,y:y});
            }
        }
        return cells;
    };
    Grid.prototype.randomAvailableCell = function(){
        var cells = this.availableCells();
        return cells.length ? cells[Math.floor(Math.random() * cells.length)] : null;
    };
    Grid.prototype.cellsAvailable = function(){
        return this.availableCells().length > 0;
    };
    Grid.prototype.cellContent = function(cell){
        return this.withinBounds(cell) ? this.cells[cell.x][cell.y] : null;
    };
    Grid.prototype.insertTile = function(tile){
        this.cells[tile.x][tile.y] = tile;
    };
    Grid.prototype.removeTile = function(tile){
        this.cells[tile.x][tile.y] = null;
    };
    Grid.prototype.withinBounds = function(pos){
        return pos.x >= 0 && pos.x < this.size && pos.y >= 0 && pos.y < this.size;
    };
    Grid.prototype.eachCell = function(cb){
        for (var x = 0; x < this.size; x++){
            for (var y = 0; y < this.size; y++) cb(x, y, this.cells[x][y]);
        }
    };

    function Tile(pos, value){
        this.x = pos.x;
        this.y = pos.y;
        this.value = value || 2;
        this.previousPosition = null;
        this.mergedFrom = null;
    }
    Tile.prototype.savePosition = function(){
        this.previousPosition = {x:this.x, y:this.y};
    };
    Tile.prototype.updatePosition = function(pos){
        this.x = pos.x;
        this.y = pos.y;
    };

    function GameManager(size){
        this.size = size;
        this.startTiles = 2;
        this.scoreEl = document.getElementById("score");
        this.bestEl = document.getElementById("best");
        this.addEl = document.getElementById("score-addition");
        this.messageEl = document.getElementById("game-message");
        this.messageText = document.getElementById("message-text");
        this.tileContainer = document.getElementById("tile-container");

        document.getElementById("restart").addEventListener("click", this.restart.bind(this));
        document.getElementById("retry").addEventListener("click", this.restart.bind(this));
        document.getElementById("keep-playing").addEventListener("click", this.keepPlaying.bind(this));

        this.inputHandler();
        this.setup();
    }

    GameManager.prototype.restart = function(){
        this.messageEl.classList.remove("show");
        this.setup();
    };
    GameManager.prototype.keepPlaying = function(){
        this.keepPlayingFlag = true;
        this.messageEl.classList.remove("show");
    };
    GameManager.prototype.isGameTerminated = function(){
        return this.over || (this.won && !this.keepPlayingFlag);
    };
    GameManager.prototype.setup = function(){
        this.grid = new Grid(this.size);
        this.score = 0;
        this.over = false;
        this.won = false;
        this.keepPlayingFlag = false;
        this.best = parseInt(localStorage.getItem(STORAGE_KEY) || "0", 10);
        for (var i = 0; i < this.startTiles; i++) this.addRandomTile();
        this.actuate();
    };
    GameManager.prototype.addRandomTile = function(){
        if (this.grid.cellsAvailable()){
            this.grid.insertTile(new Tile(this.grid.randomAvailableCell(), Math.random() < 0.9 ? 2 : 4));
        }
    };
    GameManager.prototype.actuate = function(){
        if (this.score > this.best) this.best = this.score;
        localStorage.setItem(STORAGE_KEY, this.best);

        this.tileContainer.innerHTML = "";
        var self = this;
        this.grid.eachCell(function(x, y, tile){
            if (tile) self.renderTile(tile);
        });

        this.scoreEl.textContent = this.score;
        this.bestEl.textContent = this.best;

        if (this.won && !this.keepPlayingFlag){
            this.messageText.textContent = "Вы выиграли";
            this.messageEl.classList.add("show");
        } else if (this.over){
            this.messageText.textContent = "Игра окончена";
            this.messageEl.classList.add("show");
        }
    };
    GameManager.prototype.renderTile = function(tile){
        var el = document.createElement("div");
        var classes = ["tile"];
        if (tile.mergedFrom) classes.push("tile-merged");
        else if (!tile.previousPosition) classes.push("tile-new");
        el.className = classes.join(" ");
        el.setAttribute("data-value", tile.value);
        el.textContent = tile.value;
        this.positionTile(el, tile.x, tile.y);
        this.tileContainer.appendChild(el);
    };
    GameManager.prototype.positionTile = function(el, x, y){
        var pct = 100 / this.size;
        el.style.left = (y * pct) + "%";
        el.style.top = (x * pct) + "%";
        el.style.width = "calc(" + pct + "% - 9px)";
        el.style.height = "calc(" + pct + "% - 9px)";
    };
    GameManager.prototype.showScoreAddition = function(amount){
        if (amount <= 0) return;
        this.addEl.textContent = "+" + amount;
        this.addEl.classList.remove("show");
        void this.addEl.offsetWidth;
        this.addEl.classList.add("show");
    };
    GameManager.prototype.prepareTiles = function(){
        this.grid.eachCell(function(x, y, tile){
            if (tile){
                tile.mergedFrom = null;
                tile.savePosition();
            }
        });
    };
    GameManager.prototype.moveTile = function(tile, cell){
        this.grid.cells[tile.x][tile.y] = null;
        this.grid.cells[cell.x][cell.y] = tile;
        tile.updatePosition(cell);
    };

    var directions = {
        0: {x:-1, y:0},
        1: {x:0, y:1},
        2: {x:1, y:0},
        3: {x:0, y:-1}
    };

    GameManager.prototype.getVector = function(dir){
        return directions[dir];
    };
    GameManager.prototype.buildTraversals = function(vector){
        var traversals = {x:[], y:[]};
        for (var pos = 0; pos < this.size; pos++){
            traversals.x.push(pos);
            traversals.y.push(pos);
        }
        if (vector.x === 1) traversals.x = traversals.x.reverse();
        if (vector.y === 1) traversals.y = traversals.y.reverse();
        return traversals;
    };
    GameManager.prototype.findFarthestPosition = function(cell, vector){
        var previous;
        do {
            previous = cell;
            cell = {x: previous.x + vector.x, y: previous.y + vector.y};
        } while (this.grid.withinBounds(cell) && !this.grid.cellContent(cell));
        return {farthest: previous, next: cell};
    };
    GameManager.prototype.positionsEqual = function(a, b){
        return a.x === b.x && a.y === b.y;
    };
    GameManager.prototype.tileMatchesAvailable = function(){
        if (this.grid.cellsAvailable()) return true;
        for (var x = 0; x < this.size; x++){
            for (var y = 0; y < this.size; y++){
                var tile = this.grid.cellContent({x:x, y:y});
                if (tile){
                    for (var d = 0; d < 4; d++){
                        var vector = this.getVector(d);
                        var other = this.grid.cellContent({x:x + vector.x, y:y + vector.y});
                        if (other && other.value === tile.value) return true;
                    }
                }
            }
        }
        return false;
    };
    GameManager.prototype.move = function(direction){
        if (this.isGameTerminated()) return;

        var cell, tile;
        var vector = this.getVector(direction);
        var traversals = this.buildTraversals(vector);
        var moved = false;
        var scoreGain = 0;
        var self = this;

        this.prepareTiles();

        traversals.x.forEach(function(x){
            traversals.y.forEach(function(y){
                cell = {x:x, y:y};
                tile = self.grid.cellContent(cell);
                if (!tile) return;

                var positions = self.findFarthestPosition(cell, vector);
                var next = self.grid.cellContent(positions.next);

                if (next && next.value === tile.value && !next.mergedFrom){
                    var merged = new Tile(positions.next, tile.value * 2);
                    merged.mergedFrom = [tile, next];
                    self.grid.insertTile(merged);
                    self.grid.removeTile(tile);
                    tile.updatePosition(positions.next);
                    scoreGain += merged.value;
                    if (merged.value === 2048) self.won = true;
                } else {
                    self.moveTile(tile, positions.farthest);
                }

                if (!self.positionsEqual(cell, tile)) moved = true;
            });
        });

        if (moved){
            this.score += scoreGain;
            this.addRandomTile();
            if (!this.tileMatchesAvailable()) this.over = true;
            this.actuate();
            this.showScoreAddition(scoreGain);
        }
    };
    GameManager.prototype.inputHandler = function(){
        var self = this;
        var keyMap = {37:3, 38:0, 39:1, 40:2, 65:3, 87:0, 68:1, 83:2};

        document.addEventListener("keydown", function(e){
            var mapped = keyMap[e.which];
            if (mapped !== undefined){
                e.preventDefault();
                self.move(mapped);
            }
        });

        var touchStartX, touchStartY;
        var gameContainer = document.querySelector(".game-container");

        gameContainer.addEventListener("touchstart", function(e){
            if (e.touches.length !== 1) return;
            touchStartX = e.touches[0].clientX;
            touchStartY = e.touches[0].clientY;
        }, {passive:true});

        gameContainer.addEventListener("touchend", function(e){
            if (touchStartX === undefined) return;
            var dx = e.changedTouches[0].clientX - touchStartX;
            var dy = e.changedTouches[0].clientY - touchStartY;
            var absDx = Math.abs(dx);
            var absDy = Math.abs(dy);

            if (Math.max(absDx, absDy) > 20){
                self.move(absDx > absDy ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0));
            }
            touchStartX = touchStartY = undefined;
        });
    };

    function buildGridBackground(size){
        var container = document.getElementById("grid-container");
        for (var x = 0; x < size; x++){
            var row = document.createElement("div");
            row.className = "grid-row";
            for (var y = 0; y < size; y++){
                var cellEl = document.createElement("div");
                cellEl.className = "grid-cell";
                row.appendChild(cellEl);
            }
            container.appendChild(row);
        }
    }

    buildGridBackground(SIZE);
    new GameManager(SIZE);
})();
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
