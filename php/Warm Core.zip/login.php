<?php

declare(strict_types=1);

require_once __DIR__ . '/core/bootstrap.php';

if (is_authenticated()) {
    redirect('/dash/');
}

$errors = [];
$success = flash('success');

if (isset($_GET['cancel'])) {
    unset($_SESSION['pending_login']);
    redirect('/login/');
}

$pendingLogin = $_SESSION['pending_login'] ?? null;

if (is_array($pendingLogin) && (int) ($pendingLogin['expires_at'] ?? 0) < time()) {
    unset($_SESSION['pending_login']);
    $pendingLogin = null;
    $errors[] = 'Время подтверждения истекло. Введите email и пароль снова.';
}

if (!$pendingLogin && empty($_SESSION['login_captcha'])) {
    $_SESSION['login_captcha'] = (string) random_int(10000, 99999);
}

if (!$pendingLogin && (empty($_SESSION['login_honeypot']) || !is_array($_SESSION['login_honeypot']))) {
    $_SESSION['login_honeypot'] = [
        'field' => 'contact_' . bin2hex(random_bytes(6)),
        'check' => 'confirm_' . bin2hex(random_bytes(6)),
    ];
}

$honeypot = $_SESSION['login_honeypot'] ?? ['field' => '', 'check' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($pendingLogin) {
        $code = trim((string) ($_POST['totp_code'] ?? ''));
        $submittedToken = (string) ($_POST['csrf_token'] ?? '');

        if (!hash_equals((string) $pendingLogin['csrf_token'], $submittedToken)) {
            $errors[] = 'Запрос устарел. Обновите страницу.';
        } elseif (!preg_match('/^\d{6}$/', $code)) {
            $errors[] = 'Введите шестизначный код из приложения.';
        } else {
            $statement = db()->prepare(
                'SELECT id, name, email, role, totp_secret FROM users WHERE id = :id AND topt_status = 1 AND totp_secret IS NOT NULL LIMIT 1'
            );
            $statement->execute(['id' => (int) $pendingLogin['user_id']]);
            $pendingUser = $statement->fetch();

            if (!$pendingUser || !consume_totp_code((int) $pendingUser['id'], (string) $pendingUser['totp_secret'], $code)) {
                $_SESSION['pending_login']['attempts'] = (int) ($pendingLogin['attempts'] ?? 0) + 1;
                if ($_SESSION['pending_login']['attempts'] >= 5) {
                    unset($_SESSION['pending_login']);
                    set_flash('login_error', 'Слишком много неверных кодов. Введите email и пароль снова.');
                    redirect('/login/');
                } else {
                    $errors[] = 'Неверный или уже использованный код Google Authenticator.';
                }
            } else {
                unset($_SESSION['pending_login'], $_SESSION['login_captcha'], $_SESSION['login_honeypot']);
                clear_old();
                login_user($pendingUser);
                redirect('/dash/');
            }
        }
    } else {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $captcha = trim((string) ($_POST['captcha'] ?? ''));

    if (trim((string) ($_POST[$honeypot['field']] ?? '')) !== '' || isset($_POST[$honeypot['check']])) {
        $errors[] = 'Форма отправлена некорректно.';
        $_SESSION['login_captcha'] = (string) random_int(10000, 99999);
        $_SESSION['login_honeypot'] = [
            'field' => 'contact_' . bin2hex(random_bytes(6)),
            'check' => 'confirm_' . bin2hex(random_bytes(6)),
        ];
        $honeypot = $_SESSION['login_honeypot'];
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $errors[] = 'Введите email и пароль.';
    }

    if ($captcha === '' || !hash_equals((string) $_SESSION['login_captcha'], $captcha)) {
        $errors[] = 'Введите правильный код с картинки.';
        $_SESSION['login_captcha'] = (string) random_int(10000, 99999);
    }

    if (!$errors) {
        $statement = db()->prepare('SELECT id, name, email, role, password_hash, totp_secret, topt_status FROM users WHERE email = :email LIMIT 1');
        $statement->execute(['email' => $email]);
        $user = $statement->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errors[] = 'Неверный email или пароль.';
        } elseif ((int) $user['topt_status'] === 1 && !empty($user['totp_secret'])) {
            clear_old();
            unset($_SESSION['login_captcha'], $_SESSION['login_honeypot']);
            session_regenerate_id(true);
            $_SESSION['pending_login'] = [
                'user_id' => (int) $user['id'],
                'email' => (string) $user['email'],
                'expires_at' => time() + 300,
                'attempts' => 0,
                'csrf_token' => bin2hex(random_bytes(32)),
            ];
            redirect('/login/');
        } else {
            clear_old();
            unset($_SESSION['login_captcha']);
            login_user($user);
            redirect('/dash/');
        }
    }

    store_old(['email' => $email]);
    }
}

$pageTitle = 'Вход - Warm Core';
require __DIR__ . '/partials/header.php';
?>

<section class="auth-page">
    <div class="auth-copy">
        <span class="eyebrow">Авторизация</span>
        <h1><?= $pendingLogin ? 'Подтвердите вход.' : 'Войдите в созданный аккаунт.' ?></h1>
        <p class="lead"><?= $pendingLogin ? 'Откройте Google Authenticator и введите текущий код аккаунта.' : 'После входа сайт показывает активную сессию и имя пользователя в верхней навигации.' ?></p>
    </div>

    <form class="auth-card" method="post" action="/login/" novalidate>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>

        <?php if ($loginError = flash('login_error')): ?>
            <div class="alert alert-error"><?= e($loginError) ?></div>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="alert alert-error"><?= e(implode(' ', $errors)) ?></div>
        <?php endif; ?>

        <?php if ($pendingLogin): ?>
        <input type="hidden" name="csrf_token" value="<?= e((string) $pendingLogin['csrf_token']) ?>">
        <div class="form-group">
            <label for="totp-code">Код Google Authenticator</label>
            <input id="totp-code" name="totp_code" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" autofocus required>
            <div class="form-note">Вход в аккаунт <?= e((string) $pendingLogin['email']) ?></div>
        </div>

        <div class="form-actions">
            <button class="button-primary" type="submit">Подтвердить вход</button>
            <a class="button button-secondary" href="/login/?cancel=1">Ввести данные заново</a>
        </div>
        <?php else: ?>
        <div class="form-group">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" value="<?= e(old('email')) ?>" autocomplete="email" required>
        </div>

        <div class="form-group">
            <label for="password">Пароль</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>
        </div>

        <div class="auth-honeypot" aria-hidden="true">
            <label for="<?= e($honeypot['field']) ?>">Контактный телефон</label>
            <input id="<?= e($honeypot['field']) ?>" name="<?= e($honeypot['field']) ?>" type="text" value="" tabindex="-1" autocomplete="off">
            <label class="checkbox-trap" for="<?= e($honeypot['check']) ?>">
                <input id="<?= e($honeypot['check']) ?>" name="<?= e($honeypot['check']) ?>" type="checkbox" value="1" tabindex="-1" autocomplete="off">
                Подтвердить автоматический вход
            </label>
        </div>

        <div class="form-group">
            <label for="captcha">Введите код</label>
            <div class="captcha-code" aria-label="Код подтверждения"><?= e((string) $_SESSION['login_captcha']) ?></div>
            <input id="captcha" name="captcha" type="text" inputmode="numeric" pattern="[0-9]{5}" maxlength="5" autocomplete="off" required>
        </div>

        <div class="form-actions">
            <button class="button-primary" type="submit">Войти</button>
            <div class="form-note">Нет аккаунта? <a href="/signup/">Зарегистрироваться</a></div>
        </div>
        <?php endif; ?>
    </form>
</section>

<?php require __DIR__ . '/partials/footer.php'; ?>
