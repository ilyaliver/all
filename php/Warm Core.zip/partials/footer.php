    </main>

    <footer class="site-footer">
        <div class="footer-inner">
            <div>
                <div class="footer-brand">
                    <span class="brand-mark" aria-hidden="true"></span>
                    <span>Warm Core</span>
                </div>
                <p>Базовое ядро сайта на PHP и MySQL для XAMPP.</p>
            </div>
            <p class="footer-meta">Canvas, coral, dark surface. Минимальная основа без лишних зависимостей.</p>
        </div>
    </footer>
</body>
</html>
