<?php
$user = ($skipUserLookup ?? false) ? null : current_user();
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Warm Core') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
    <header class="site-header">
        <a class="site-logo" href="/" aria-label="Warm Core">
            <span class="brand-mark" aria-hidden="true"></span>
            <span>Warm Core</span>
        </a>

        <div class="header-actions">
            <nav class="site-nav" aria-label="Главная навигация">
                <a href="/">Главная</a>
                <?php if ($user): ?>
                    <a href="/dash/">Кабинет</a>
                <?php endif; ?>
            </nav>

            <div class="site-auth">
                <?php if ($user): ?>
                    <span class="nav-user">Здравствуйте, <?= e($user['name']) ?></span>
                    <a class="button button-secondary" href="/logout.php">Выйти</a>
                <?php else: ?>
                    <a href="/login/">Вход</a>
                    <a class="button button-primary" href="/signup/">Регистрация</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <main class="main-wrap">
